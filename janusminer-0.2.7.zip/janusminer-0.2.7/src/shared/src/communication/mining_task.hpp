#pragma once

#include "block/block.hpp"

struct MiningTask {
    Block block;
};
