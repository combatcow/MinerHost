#pragma once
#include <cstddef>
class Reader;
template <size_t>
class ReaderCheck;
