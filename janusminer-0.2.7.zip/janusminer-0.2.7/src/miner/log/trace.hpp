#pragma once
#include"spdlog/spdlog.h"

spdlog::logger& trace_log();
